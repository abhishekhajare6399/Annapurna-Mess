<?php include'uheader.php'?>
	<!-- end search area -->

	<style>
.hero-bg {
  background-image: url('<?php echo $bg?>');
  background-size: cover;
  background-position: center;
  background-attachment: fixed;
}
      </style>

	<!-- hero area -->
	<div class="hero-area hero-bg">
		<div class="container">
			<div class="row">
				<div class="col-lg-9 offset-lg-2 text-center">
					<div class="hero-text">
						<div class="hero-text-tablecell">
							<h3 style="color:white;">Welcome <?php echo $name?></h3>
							<h1><?php echo $mess?><h1>
						<a href="uscan.php"><button type="button" class="btn btn-warning">Scan QR Code</button></button></a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- end hero area -->

	<!-- features list section -->
	<div class="list-section pt-80 pb-80">
		<div class="container">
			<div class="row">
				<div class="col-lg-4 col-md-6 mb-4 mb-lg-0">
					
						<div class="content">
							<h3>Today's Menu :</h3>
							<?php
							 include'database/dbcon.php';
							 date_default_timezone_set("Asia/Calcutta");
							 $date =date('Y-m-d');
							 $messid=$_SESSION['messid'];
							 $query = "SELECT * FROM menu where messid='$messid' and date='$date' order by id DESC limit 1";
							 $result = mysqli_query($con,$query);
							 while($row = mysqli_fetch_array($result))
							 {
								 ?>
								 <p>Food Type : <?php echo $row['foodtype'];?></p>
								 <p>Time : <?php echo $row['time'];?></p>
								 <p>Menu : <?php echo $row['menu'];?></p>
							<?php }
							?>



					
					</div>
				</div>
			</div>

		</div>
	</div>
	<!-- end features list section -->

	

	<!-- latest news -->
	<div class="latest-news pt-150 pb-150">
		<div class="container">

			<div class="row">
				<div class="col-lg-8 offset-lg-2 text-center">
					<div class="section-title">	
						<h3><span class="orange-text">Our</span> Membership</h3>
						<p>We offer Three type of memberships.</p>
					</div>
				</div>
			</div>

			<div class="row">
				<div class="col-lg-4 col-md-6">
					<div class="single-latest-news">
						<a href="single-news.html"><div class="latest-news-bg news-bg-1"></div></a>
						<div class="news-text-box">
							<h3><a href="single-news.html">Regular Customer.</a></h3>
							<p class="blog-meta">
								<span class="author">Mess Charge</span>
								<span class="date">2700 Rs.</span>
							</p>
							<p class="excerpt">Vivamus lacus enim, pulvinar vel nulla sed, scelerisque rhoncus nisi. Praesent vitae mattis nunc, egestas viverra eros.</p>
							<a href="single-news.html" class="read-more-btn">read more <i class="fas fa-angle-right"></i></a>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6">
					<div class="single-latest-news">
						<a href="single-news.html"><div class="latest-news-bg news-bg-2"></div></a>
						<div class="news-text-box">
							<h3><a href="single-news.html">A man's worth has its season, like tomato.</a></h3>
							<p class="blog-meta">
								<span class="author"><i class="fas fa-user"></i> Admin</span>
								<span class="date"><i class="fas fa-calendar"></i> 27 December, 2019</span>
							</p>
							<p class="excerpt">Vivamus lacus enim, pulvinar vel nulla sed, scelerisque rhoncus nisi. Praesent vitae mattis nunc, egestas viverra eros.</p>
							<a href="single-news.html" class="read-more-btn">read more <i class="fas fa-angle-right"></i></a>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6 offset-md-3 offset-lg-0">
					<div class="single-latest-news">
						<a href="single-news.html"><div class="latest-news-bg news-bg-3"></div></a>
						<div class="news-text-box">
							<h3><a href="single-news.html">Good thoughts bear good fresh juicy fruit.</a></h3>
							<p class="blog-meta">
								<span class="author"><i class="fas fa-user"></i> Admin</span>
								<span class="date"><i class="fas fa-calendar"></i> 27 December, 2019</span>
							</p>
							<p class="excerpt">Vivamus lacus enim, pulvinar vel nulla sed, scelerisque rhoncus nisi. Praesent vitae mattis nunc, egestas viverra eros.</p>
							<a href="single-news.html" class="read-more-btn">read more <i class="fas fa-angle-right"></i></a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- end latest news -->

	<!-- footer -->
	<?php include'ufooter.php'?>

</body>
</html>