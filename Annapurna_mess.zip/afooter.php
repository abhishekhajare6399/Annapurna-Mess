<footer class="container-fluid">
    <p>© String software services.
All rights reserved.</p>
  </footer>