<head>
<title><?php echo $name?></title>
<link rel="icon" href="<?php echo $logo?>" />
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
 
  </style>
  <?php include"link/link.php"?>
  <?php include"css/style.php"?>
</head>